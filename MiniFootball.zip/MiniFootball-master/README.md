# MiniFootball
OOP Final Project

                                            CREATORS
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Utegen Asylzhan

Sabyrbek Madiyar

Alimkhan Aitugan

                                        *Description*
This is the console game. Where you can create team and play. You can have 2 results you will win a lot of matches and become reach or bankrupt.
Good luck!!! In this game luck is everything that you need.
